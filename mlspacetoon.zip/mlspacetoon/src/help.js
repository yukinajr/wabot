const help = (prefix) => { 
	return `*_mlspacetoon_*

╔══❖ 〘 *INFORMATION* 〙 ❖══╗
├─❖ *BOT TYPE : JavaScript*
├─❖ *NAME : MLSPACETOON 𝗕𝗢𝗧*
├─❖ *VERSION NEW : v4.0*
├─❖ *FREE : Yes*
├─❖ *VIP : Yes*
├─❖ *VVIP : No*
├─❖ *VVVIP : No*
├─❖ *PREMIUM : Yes*
╰─────────────────────────

[ ! ] _Apa itu prefix?_
Awalan atau prefiks adalah sebuah afiks yang dibubuhkan pada awal sebuah kata dasar
*Contoh* : 「 #!$?.% 」


╭◪ 𝐑𝐮𝐥𝐞𝐬𝐒 
╰─────────────────────────
├❖ *Spam : Auto Block!*
├❖ *Setidaknya Beri Jeda 5 Detik!*
├❖ *Bug/Error Harap Chat Owner!*
├❖ *Fitur sebagian membutuhkan Apikey!*
├❖ *Gunakan Bot Dengan Bijak!*
╰─────────────────────────

╭◪ 𝐋𝐈𝐒𝐓 𝐌𝐄𝐍𝐔
├❍ *Perintah/Command : 「 ${prefix} 」*
├❍ *Limit BOT    : NO Limit*
├❍ *Harap Jangan menSpam BOT.*
├❍ *Inget beri jeda 5 Detik.*
├─────────────────────────
╰─❖ *${prefix}ownermenu*
╭─❖ *${prefix}adminmenu*
╰─❖ *${prefix}funmenu*
╭─❖ *${prefix}mediamenu*
╰─❖ *${prefix}kerangmenu*
╭─❖ *${prefix}makermenu*
╰─❖ *${prefix}othermenu*
╭─❖ *${prefix}animemenu*
╰─❖ *${prefix}nsfwmenh*
╭─❖ *${prefix}vipmenu*
╰─❖ *${prefix}listmenu*
╭─❖ *${prefix}bugreport*
╰─❖ *${prefix}glass*
╭─❖ *${prefix}profile*
╰─❖ *${prefix}owner*
╭─❖ *${prefix}request*
╰─❖ *${prefix}setprefix*
╭─❖ *${prefix}listblock*
╰─❖ *${prefix}iklan*
╭─❖ *${prefix}runtime*
╰─❖ *${prefix}rules*
╭─❖ *${prefix}tnc*
╰─❖ *${prefix}cekvip*
╭─❖ *${prefix}daftarvip*
╰─❖ *${prefix}addvip*
╭─❖ *${prefix}dellvip*
╰─❖ *${prefix}snk*
╭─❖ *${prefix}listpremium*
╰─❖ *${prefix}donate*
╭─❖ *${prefix}fitnah*
╰─❖ *${prefix}totaluser*
╭─❖ *${prefix}level*
╰─❖ *${prefix}leveling*
╭─❖ *${prefix}apiteks [𝚝𝚎𝚔𝚜]*
╰─❖ *${prefix}airteks [𝚝𝚎𝚔𝚜]*
╭─❖ *${prefix}metalteks [𝚝𝚎𝚔𝚜]*
╰─❖ *${prefix}mlogo [𝚝𝚎𝚔𝚜]*
╭─❖ *${prefix}ffbaner [𝚝𝚎𝚔𝚜]*
╰─❖ *${prefix}embun [𝚝𝚎𝚡𝚝]*
╭─❖ *${prefix}kunciteks [𝚝𝚎𝚡𝚝]*
╰─❖ *${prefix}say*
╭─❖ *${prefix}addsay [𝚝𝚎𝚡𝚝]*
╰─❖ *${prefix}listsay*
╭─❖ *${prefix}bacot*
╰─❖ *${prefix}addbacot [𝚝𝚎𝚡𝚝]*
╭─❖ *${prefix}listbacot*
╰─❖ *${prefix}resetbacot*
╭─❖ *${prefix}aguse*
╰─❖ *${prefix}kicktime*
╭─❖ *${prefix}nobg*
╰─❖ *${prefix}url2img*

☬  ɾìցհէ  հąղժ  օƒ  էհҽ  ҍօէ 
╭────────────
│ᴹ ᴴ ᴬ ᴺ ᴷ ᴮ ᴬ ᴿ ᴮ ᴬ ᴿ 
│ᴬ ᴰ ᴵ ᵂ ᴬ ᴶ ˢ ᴴ ᴵ ᴺ ᴳ  
│ˣ ᴾ ᵀ ᴺ  
│ᵀ ᴼ ᴮ ᶻ  
│ᴹ ᴬ ˢ ᴸ ᴱ ᴺ ᵀ 
│ᶜ ᴬ ᴸ ᴵ ᴾ ᴴ  
│ᴿ ᴵ ᶻ ᴷ ᵞ 
│ᴹ ᴸ ˢ ᴾ ᴬ ᶜ ᴱ ᵀ ᴼ ᴼ ᴺ 
╰────────────

          ║▌│█║▌│ █║▌│█│║▌║
          ║▌│█║▌│ █║▌│█│║▌║
   
                   © *mlspacetoon 2021*

`
}
exports.help = help
